<?php

Route::get('/', 'HomeController@index');

Route::get('/usuarios', 'UserController@index')
    ->name('users.index');

Route::get('/usuarios/{user}', 'UserController@show')
    ->where('user', '[0-9]+')
    ->name('users.show');

Route::get('/usuarios/nuevo', 'UserController@create')->name('users.create');

Route::post('/usuarios', 'UserController@store');

Route::get('/usuarios/{user}/editar', 'UserController@edit')->name('users.edit');

Route::put('/usuarios/{user}', 'UserController@update');

Route::delete('/users/{user}', 'UserController@destroy')->name('users.destroy');

Route::get('/productos', 'ProductController@index')
    ->name('products.index');

Route::get('/productos/{product}', 'ProductController@show')
    ->where('product', '[0-9]+')
    ->name('products.show');

Route::get('/productos/nuevo', 'ProductController@create')->name('products.create');

Route::post('/productos', 'ProductController@store');

Route::get('/productos/{producto}/editar', 'ProductController@edit')->name('products.edit');

Route::put('/productos/{producto}', 'ProductController@update');

Route::get('/saludo/{name}/{nickname?}', 'WelcomeUserController');

Route::delete('/productos/{product}', 'ProductController@destroy')->name('products.destroy');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
