<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index()
    {
        //$products = DB::table('products')->get();
        $products = Product::all();

        $title = 'Listado de productos';

//        return view('products.index')
//            ->with('products', Product::all())
//            ->with('title', 'Listado de productos');

        return view('products.index', compact('title', 'products'));
    }

    public function show(Product $product)
    {
        return view('products.show', compact('product'));
    }

    public function create()
    {
        return view('products.create');
    }

    public function store()
    {
        $data = request()->validate([
            'marca' => 'required',
            'modelo' => 'required',
            'talla' => 'required',
            'precio' => 'required',
        ], [
            'marca.required' => 'El campo marca es obligatorio'
        ]);

        Product::create([
            'marca' => $data['marca'],
            'modelo' => $data['modelo'],
            'talla' => $data['talla'],
            'precio' => $data['precio'],
        ]);

        return redirect()->route('products.index');
    }

    public function edit(Product $product)
    {
        return view('products.edit', ['product' => $product]);
    }

    public function update(Product $product)
    {
        $data = request()->validate([
            'marca' => 'required',
            'modelo' => 'required'->ignore($product->id),
            'talla' => 'required',
        ]);

        $product->update($data);

        return redirect()->route('products.show', ['product' => $product]);
    }

    function destroy(Product $product)
    {
        $product->delete();

        return redirect()->route('products.index');
    }
}
