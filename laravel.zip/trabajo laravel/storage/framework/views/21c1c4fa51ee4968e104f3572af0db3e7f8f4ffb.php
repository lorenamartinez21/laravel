<?php $__env->startSection('title', "Crear producto"); ?>

<?php $__env->startSection('content'); ?>
    <h1>Editar producto</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <h6>Por favor corrige los errores debajo:</h6>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(url("products/{$product->id}")); ?>">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>


        <label for="marca">Marca:</label>
        <input type="text" name="marca" id="marca" placeholder="Nike" value="<?php echo e(old('marca', $product->marca)); ?>">
        <br>
        <label for="modelo">Modelo:</label>
        <input type="text" name="modelo" id="modelo" placeholder="Air Force" value="<?php echo e(old('modelo', $product->modelo)); ?>">
        <br>
        <label for="talla">Talla:</label>
        <input type="number" name="talla" id="talla" placeholder="38" value="<?php echo e(old('talla', $product->talla)); ?>">
        <br>
        <label for="precio">Precio:</label>
        <input type="text" name="precio" id="precio" placeholder="38" value="<?php echo e(old('precio', $product->precio)); ?>">
        <button type="submit">Actualizar producto</button>
    </form>

    <p>
        <a href="<?php echo e(route('products.index')); ?>">Regresar al listado de productos</a>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lavarel\proyecto\resources\views/products/edit.blade.php ENDPATH**/ ?>