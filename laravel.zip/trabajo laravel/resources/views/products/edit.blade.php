@extends('layout')

@section('title', "Crear producto")

@section('content')
    <h1>Editar producto</h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <h6>Por favor corrige los errores debajo:</h6>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ url("products/{$product->id}") }}">
        {{ method_field('PUT') }}
        {{ csrf_field() }}

        <label for="marca">Marca:</label>
        <input type="text" name="marca" id="marca" placeholder="Nike" value="{{ old('marca', $product->marca) }}">
        <br>
        <label for="modelo">Modelo:</label>
        <input type="text" name="modelo" id="modelo" placeholder="Air Force" value="{{ old('modelo', $product->modelo) }}">
        <br>
        <label for="talla">Talla:</label>
        <input type="number" name="talla" id="talla" placeholder="38" value="{{ old('talla', $product->talla) }}">
        <br>
        <label for="precio">Precio:</label>
        <input type="text" name="precio" id="precio" placeholder="38" value="{{ old('precio', $product->precio) }}">
        <button type="submit">Actualizar producto</button>
    </form>

    <p>
        <a href="{{ route('products.index') }}">Regresar al listado de productos</a>
    </p>
@endsection